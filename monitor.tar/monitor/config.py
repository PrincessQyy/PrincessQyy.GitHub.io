import commands


# get hostname
def get_hostname():
    try:
        cmd = "hostname"
        hostname = commands.getoutput(cmd)
    except:
        ErrorInfo = r'get_hostname_error'
        print ErrorInfo
        return ErrorInfo
    return hostname

hostname = {
    "hostname" : get_hostname(),
}
# request url and port
# URL = "http://monitor.qiyuyue.com:5000/get_data"
URL = "http://192.168.33.1:80/data/"

