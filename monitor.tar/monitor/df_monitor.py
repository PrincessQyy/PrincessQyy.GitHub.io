# coding=utf-8
import os
import re
from log import init_log

#磁盘使用情况
def get_hd_use():
    logger = init_log()
    cmd_get_hd_use = '/bin/df'
    try:
        fp = os.popen(cmd_get_hd_use)
    except:
        ErrorInfo = r'get_hd_use_error'
        print ErrorInfo
        logger.error(ErrorInfo)
        return ErrorInfo
    re_obj = re.compile(r'^/dev/.+\s+(?P<used>\d+)%\s+(?P<mount>.+)')
    hd_use = {}
    for line in fp:
        match = re_obj.search(line)
        if match is not None:
            hd_use[match.groupdict()['mount']] = match.groupdict()['used']
    fp.close()

    return hd_use


hd_use = get_hd_use()
df={}
for key in hd_use.keys():
    temp_key ="/dev"+key+"_use"
    temp_value = int(hd_use[key])/100
    df[temp_key] = ("%.4f" % temp_value)


