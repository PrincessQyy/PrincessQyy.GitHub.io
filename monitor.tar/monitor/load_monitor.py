# coding=utf-8
import commands
from log import init_log

#系统负载
def get_load():
    logger = init_log()
    try:
        cmd="cat /proc/loadavg | awk '{print $1}'"
        load_1min=commands.getoutput(cmd)
    except:
        ErrorInfo = r'get_load_error'
        print ErrorInfo
        logger.error(ErrorInfo)
        return ErrorInfo

    return load_1min



load = {
    "load":get_load()
}
