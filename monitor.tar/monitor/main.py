# coding=utf-8
import sys
import json
import requests
from config import hostname,URL
from cpu_monitor import cpu
from df_monitor import df
from kernel_monitor import kernel
from load_monitor import load
from mem_monitor import mem
from snmp_monitor import snmp
from tcp_monitor import tcp
from log import init_log
import datetime
def main(logger):

    try:
        time = datetime.datetime.now().strftime('%Y-%m-%d-%H:%M')
        time = {"time":time}
        monitor_data = dict(cpu.items()+df.items()+kernel.items()+load.items()+mem.items()+snmp.items()+tcp.items()+hostname.items()+time.items())
        print "get monitor_data success"
        logger.info("get monitor_data success ^-^")
    
        url = URL
        a = requests.post(url=url, json=monitor_data)
    except:
        ErrorInfo = r'push_to_monitor_error'
        print ErrorInfo
        logger.error(ErrorInfo)

    print 'Success push data!'
    logger.info("push to monitor success ^-^")


if __name__ == "__main__":
    logger=init_log()
    main(logger)
