# coding=utf-8
import time
import os
import logging
from logging.handlers import RotatingFileHandler
def init_log():
    monitorstatuslogger = logging.getLogger('monitorstatus')
    monitorstatuslogger.setLevel(logging.INFO)
    monitorstatushandle = RotatingFileHandler('/home/qiyuyue/monitorstatus.log', maxBytes = 100*1024*1024, backupCount = 20)
    formatter = logging.Formatter('%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s')
    monitorstatushandle.setFormatter(formatter)
    monitorstatuslogger.addHandler(monitorstatushandle)
    return monitorstatuslogger