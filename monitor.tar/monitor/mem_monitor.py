# coding=utf-8
import commands
from log import init_log

#空闲内存比例
def menfree():
    logger = init_log()
    try:
        cmd="cat /proc/meminfo | grep MemFree | awk '{print $2}'"
        singel_memfree = commands.getoutput(cmd)

        cmd2="cat /proc/meminfo | grep ^Cached: | awk '{print $2}'"
        cached = commands.getoutput(cmd2)

        cmd3 = "cat /proc/meminfo | grep Buffers | awk '{print $2}'"
        buffers = commands.getoutput(cmd3)

        memfree= float(singel_memfree)+float(cached)+float(buffers)

        cmd4="cat /proc/meminfo | grep MemTotal | awk '{print $2}'"
        memtotal = commands.getoutput(cmd4)

        memfree_percent= memfree / float(memtotal)

        memfree_percent=("%.4f" % memfree_percent)

    except:
        ErrorInfo = r'get_memfree_error'
        print ErrorInfo
        logger.error(ErrorInfo)
        return ErrorInfo

    return memfree_percent

#交换分区比例
def swapfree():
    logger = init_log()
    try:
        cmd="cat /proc/meminfo | grep SwapFree | awk '{print $2}'"
        swapfree = commands.getoutput(cmd)
        cmd2="cat /proc/meminfo | grep SwapTotal | awk '{print $2}'"
        swaptotal = commands.getoutput(cmd2)

        swapfree_percent=float(swapfree)/float(swaptotal)

        swapfree_percent=("%.4f" % swapfree_percent)

    except:
        ErrorInfo = r'get_swapfree_error'
        print ErrorInfo
        logger.error(ErrorInfo)
        return ErrorInfo
    return swapfree_percent


mem = {
    "menfree_percent" : menfree(),
    "swapfree_percent" : swapfree()

}

