# -*- coding:utf-8 -*-
import commands
from log import init_log
#cpu 空闲率

def getCpuIdle():
    logger=init_log()
    try:
        cmd=" sed -n '1p' /proc/stat | awk '{print $5}' "
        idle=commands.getoutput(cmd)
        cmd2="sed -n '1p' /proc/stat | awk '{for(i=1;i<NF;i++)sum+=$i;print sum}'"
        cpu_total=commands.getoutput(cmd2)
        cpu_idle=float(idle)/float(cpu_total)
        cpu_idle=("%.4f" % cpu_idle)
    except:
        ErrorInfo = r'get_cpu_idle_error'
        print ErrorInfo
        logger.error(ErrorInfo)
        return ErrorInfo

    return (cpu_idle)

#cpu iowait
def getCpuIowait():
    logger=init_log()
    try:
        cmd = " sed -n '1p' /proc/stat | awk '{print $6}' "
        iowait = commands.getoutput(cmd)
        cmd2 = "sed -n '1p' /proc/stat | awk '{for(i=1;i<NF;i++)sum+=$i;print sum}'"
        cpu_total = commands.getoutput(cmd2)
        cpu_iowait = float(iowait) / float(cpu_total)
        cpu_iowait=("%.4f" % cpu_iowait)
    except:
        ErrorInfo = r'get_cpu_iowait_error'
        print ErrorInfo
        logger.error(ErrorInfo)
        return ErrorInfo

    return cpu_iowait

#cpu 硬中断
def getCpuIrq():
    logger=init_log()
    try:
        cmd = " sed -n '1p' /proc/stat | awk '{print $7}' "
        irq = commands.getoutput(cmd)
        cmd2 = "sed -n '1p' /proc/stat | awk '{for(i=1;i<NF;i++)sum+=$i;print sum}'"
        cpu_total = commands.getoutput(cmd2)
        cpu_irq = float(irq) / float(cpu_total)
        cpu_irq=("%.4f" % cpu_irq)
    except:
        ErrorInfo = r'get_cpu_irq_error'
        print ErrorInfo
        logger.error(ErrorInfo)
        return ErrorInfo
    return cpu_irq

#cpu 软中断
def getCpuSoftirq():
    logger=init_log()
    try:
        cmd = " sed -n '1p' /proc/stat | awk '{print $8}' "
        softirq = commands.getoutput(cmd)
        cmd2 = "sed -n '1p' /proc/stat | awk '{for(i=1;i<NF;i++)sum+=$i;print sum}'"
        cpu_total = commands.getoutput(cmd2)
        cpu_softirq = float(softirq) / float(cpu_total)
        cpu_softirq=("%.4f" %cpu_softirq )
    except:
        ErrorInfo = r'get_cpu_softirq_error'
        print ErrorInfo
        logger.error(ErrorInfo)
        return ErrorInfo

    return cpu_softirq



cpu={
    "cpu_idle" : getCpuIdle(),
    "cpu_iowait" :getCpuIowait(),
    "cpu_irq" : getCpuIrq(),
    "cpu_softirq" : getCpuSoftirq()
}

    #add_to_monitor
    #cpu_json = json.dumps(cpu)
    # cpu = {
    #     "hostname":"test-01",
    #     "cpu_idle":"26",
    # }



