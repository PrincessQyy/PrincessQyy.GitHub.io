# coding=utf-8
import  commands
from log import init_log
#当前连接数
def getTcpCurrEstab():
    logger = init_log()
    try:
        cmd="cat /proc/net/snmp | grep Tcp: | sed -n '2p' | awk '{print $10}'"
        tcp_CurrEstab=commands.getoutput(cmd)
    except:
        ErrorInfo = r'get_snmp_TcpCurrEstab_error'
        print ErrorInfo
        logger.error(ErrorInfo)
        return ErrorInfo
    return tcp_CurrEstab

#错误包数
def getTcpInErrs():
    logger = init_log()
    try:
        cmd = "cat /proc/net/snmp | grep Tcp: | sed -n '2p' | awk '{print $14}'"
        tcp_InErrs = commands.getoutput(cmd)
    except:
        ErrorInfo = r'get_snmp_TcpInErrs_error'
        print ErrorInfo
        logger.error(ErrorInfo)
        return ErrorInfo
    return tcp_InErrs

#收到包总数
def getTcpInSegs():
    logger = init_log()
    try:
        cmd = "cat /proc/net/snmp | grep Tcp: | sed -n '2p' | awk '{print $11}'"
        tcp_InSegs = commands.getoutput(cmd)
    except:
        ErrorInfo = r'get_snmp_TcpInSegs_error'
        print ErrorInfo
        logger.error(ErrorInfo)
        return ErrorInfo
    return tcp_InSegs

#发出的包总数
def getTcpOutSegs():
    logger = init_log()
    try:
        cmd = "cat /proc/net/snmp | grep Tcp: | sed -n '2p' | awk '{print $12}'"
        tcp_OutSegs = commands.getoutput(cmd)
    except:
        ErrorInfo = r'get_snmp_TcpOutSegs_error'
        print ErrorInfo
        logger.error(ErrorInfo)
        return ErrorInfo
    return tcp_OutSegs


#收包总数
def getUdpInDatagrams():
    logger = init_log()
    try:
        cmd = "cat /proc/net/snmp | grep Udp: | sed -n '2p' | awk '{print $2}'"
        udp_InDatagrams = commands.getoutput(cmd)
    except:
        ErrorInfo = r'get_snmp_UdpInDatagrams_error'
        print ErrorInfo
        logger.error(ErrorInfo)
        return ErrorInfo
    return udp_InDatagrams

#发包总数
def getUdpOutDatagrams():
    logger = init_log()
    try:
        cmd = "cat /proc/net/snmp | grep Udp: | sed -n '2p' | awk '{print $5}'"
        udp_OutDatagrams = commands.getoutput(cmd)
    except:
        ErrorInfo = r'get_snmp_UdpOutDatagrams_error'
        print ErrorInfo
        logger.error(ErrorInfo)
        return ErrorInfo
    return udp_OutDatagrams

#错误包总数
def getUdpInErrors():
    logger = init_log()
    try:
        cmd = "cat /proc/net/snmp | grep Udp: | sed -n '2p' | awk '{print $4}'"
        udp_InErrors = commands.getoutput(cmd)
    except:
        ErrorInfo = r'get_snmp_UdpInErrs_error'
        print ErrorInfo
        logger.error(ErrorInfo)
        return ErrorInfo
    return udp_InErrors



snmp = {
    "tcp_CurrEstab":getTcpCurrEstab(),
    "tcp_InErrs":getTcpInErrs(),
    "tcp_InSegs":getTcpInSegs(),
    "tcp_OutSegs":getTcpOutSegs(),
    "udp_InDatagrams":getUdpInDatagrams(),
    "udp_OutDatagrams":getUdpOutDatagrams(),
    "udp_InErrs":getUdpInErrors()

}


