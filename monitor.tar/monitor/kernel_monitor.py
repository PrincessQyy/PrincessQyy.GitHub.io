# coding=utf-8
import commands
from log import init_log

#已分配文件描述符比例
def get_files_percent():
    logger = init_log()
    try:
        cmd = "cat /proc/sys/fs/file-nr | awk '{print $1}'"
        files_allocated = commands.getoutput(cmd)

        cmd2 = "cat /proc/sys/fs/file-max | awk '{print $1}'"
        files_max = commands.getoutput(cmd2)

        files_percent = float(files_allocated) / float(files_max)

        files_percent=("%.4f" % files_percent)
    except:
        ErrorInfo = r'get_kernel_data_error'
        logger.error(ErrorInfo)
        print ErrorInfo
        return ErrorInfo
    return files_percent


kernel = {
    "files_percent":get_files_percent()
}

