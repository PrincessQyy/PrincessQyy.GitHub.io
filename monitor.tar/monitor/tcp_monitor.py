# coding=utf-8
import commands
from log import init_log

#超出listen队列的连接数
def get_TcpListenOverflows():
    logger = init_log()
    try:
        cmd = " cat /proc/net/netstat | grep TcpExt: | sed -n '2p' | awk '{print $21}'"
        TcpListenOverflows = commands.getoutput(cmd)
    except:
        ErrorInfo = r'get_TcpListenOverflows_error'
        print ErrorInfo
        logger.error(ErrorInfo)
        return ErrorInfo
    return TcpListenOverflows

#丢包数
def get_TcpListenDrops():
    logger = init_log()
    try:
        cmd = " cat /proc/net/netstat | grep TcpExt: | sed -n '2p' | awk '{print $22}'"
        TcpListenDrops = commands.getoutput(cmd)
    except:
        ErrorInfo = r'get_TcpListenDrops_error'
        print ErrorInfo
        logger.error(ErrorInfo)
        return ErrorInfo
    return TcpListenDrops

#丢包恢复的次数
def get_TCPLoss():
    logger = init_log()
    try:
        cmd = " cat /proc/net/netstat | grep TcpExt: | sed -n '2p' | awk '{print $42}'"
        TCPLoss = commands.getoutput(cmd)
    except:
        ErrorInfo = r'get_TcpLoss_error'
        print ErrorInfo
        logger.error(ErrorInfo)
        return ErrorInfo
    return TCPLoss

#丢包恢复失败
def get_TCPLossFailures():
    logger = init_log()
    try:
        cmd = " cat /proc/net/netstat | grep TcpExt: | sed -n '2p' | awk '{print $46}'"
        TCPLossFailures = commands.getoutput(cmd)
    except:
        ErrorInfo = r'get_TcpLossFailures_error'
        print ErrorInfo
        logger.error(ErrorInfo)
        return ErrorInfo
    return TCPLossFailures

#尝试结束链接失败的次数
def get_TCPAbortFailed():
    logger = init_log()
    try:
        cmd = " cat /proc/net/netstat | grep TcpExt: | sed -n '2p' | awk '{print $64}'"
        TCPAbortFailed = commands.getoutput(cmd)
    except:
        ErrorInfo = r'get_TcpAbortFailed_error'
        print ErrorInfo
        logger.error(ErrorInfo)
        return ErrorInfo
    return  TCPAbortFailed

#因内存关闭链接的次数
def get_TCPAbortOnMemory():
    logger = init_log()
    try:
        cmd = " cat /proc/net/netstat | grep TcpExt: | sed -n '2p' | awk '{print $61}'"
        TCPAbortOnMemory = commands.getoutput(cmd)
    except:
        ErrorInfo = r'get_TcpAbortOnMemory_error'
        print ErrorInfo
        logger.error(ErrorInfo)
        return ErrorInfo
    return TCPAbortOnMemory

#虚假超时次数
def get_TCPSpuriousRTOs():
    logger = init_log()
    try:
        cmd = " cat /proc/net/netstat | grep TcpExt: | sed -n '2p' | awk '{print $69}'"
        TCPSpuriousRTOs = commands.getoutput(cmd)
    except:
        ErrorInfo = r'get_TcpSpuriousRTOs_error'
        print ErrorInfo
        logger.error(ErrorInfo)
        return ErrorInfo
    return TCPSpuriousRTOs

#正常超时次数
def get_TW():
    logger = init_log()
    try:
        cmd = " cat /proc/net/netstat | grep TcpExt: | sed -n '2p' | awk '{print $12}'"
        TW = commands.getoutput(cmd)
    except:
        ErrorInfo = r'get_TW_error'
        print ErrorInfo
        logger.info(ErrorInfo)
        return ErrorInfo
    return TW

#乱序次数
def get_TCPTSReorder():
    logger = init_log()
    try:
        cmd = " cat /proc/net/netstat | grep TcpExt: | sed -n '2p' | awk '{print $37}'"
        TCPTSReorder = commands.getoutput(cmd)
    except:
        ErrorInfo = r'get_TCPSReorder_error'
        print ErrorInfo
        logger.error(ErrorInfo)
        return ErrorInfo
    return TCPTSReorder



tcp ={
    "TcpListenOverflows" : get_TcpListenOverflows(),
    "TcpListenDrops" : get_TcpListenDrops(),
    "TCPLoss" : get_TCPLoss(),
    "TCPLossFailures" : get_TCPLossFailures() ,
    "TCPAbortFailed" : get_TCPAbortFailed(),
    "TCPAbortOnMemory" : get_TCPAbortOnMemory(),
    "TCPSpuriousRTOs" : get_TCPSpuriousRTOs(),
    "TW" : get_TW(),
    "TCPTSReorder" : get_TCPTSReorder()
}

