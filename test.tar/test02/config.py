# coding=utf-8
import os

SECRET_KEY = os.urandom(24)

DEBUG = True

#mysql
HOSTNAME = "127.0.0.1"
PORT = "3306"
DATABASE = "monitor_manager"
USERNAME = "root"
PASSWORD = "Princess143."
DB_URI = DB_URI = "mysql+mysqldb://{}:{}@{}:{}/{}?charset=utf8".format(USERNAME,PASSWORD,HOSTNAME,PORT,DATABASE)
SQLALCHEMY_DATABASE_URI = DB_URI

SQLALCHEMY_TRACK_MODIFICATIONS = False

Y_dict={
    "tcp_InSegs":20000,
    "TCPAbortFailed":100,
    "TCPLossFailures":100,
    "tcp_OutSegs":20000,
    "TCPAbortOnMemory":100,
    "TCPLoss":100,
    "cpu_iowait":1,
    "udp_OutDatagrams":500,
    "menfree_percent":1,
    "udp_InDatagrams":500,
    "cpu_idle":1,
    "TCPTSReorder":100,
    "tcp_CurrEstab":500,
    "TCPSpuriousRTOs":500,
    "cpu_irq":1,
    "cpu_softirq":1,
    "files_percent":1,
    "TcpListenOverflows":100,
    "tcp_InErrs":100,
    "load":1,
    "udp_InErrs":100,
    "TcpListenDrops":100,
    "swapfree_percent":1,
    "/dev/boot_use":1,
    "TW":1000,


}