# coding=utf-8
from flask import (
    Flask,
    render_template,
    session,
    request
)
import config
from decorators import login_required
from WebPlatform.users.views import bp as user_bp
from  WebPlatform.data.views import bp as data_bp
from exts import db
from models import User
from redis import Redis
import re

app = Flask(__name__)
app.config.from_object(config)
#regist blueprint
app.register_blueprint(user_bp)
app.register_blueprint(data_bp)

db.init_app(app)

@app.route('/',methods=['GET','POST'])
#@login_required
def index():
    if request.method == 'GET':
        return render_template('index.html')
    else:

        # get all hosts
        cache = Redis(host='127.0.0.1', port=6379)
        hosts = cache.keys()

        # get monitor_item
        search_item = request.form.get("item", "")
        print  request.form.getlist("host")
        if search_item:
            items = []
            # save hostname
            hosts = request.form.getlist("host")
            # get all items
            for host in hosts:
                item_dict = cache.hgetall(host)
                for each in item_dict.keys():
                    if search_item in each:
                        temp=host+"."+each
                        items.append(temp)

            context = {
                "hosts": hosts,
                "items": items
            }

            return render_template('index.html', **context)



        #get search_hostname
        search_host = request.form.get("host", "")

        # 如果成立 代表左侧查询
        if search_host:
            #get search list
            search_host_list=[]
            for host in hosts:
                if search_host in host:
                    search_host_list.append(host)


            context = {
                "hosts": search_host_list  # type is list
            }

            return render_template('index.html', **context)
        elif search_host=="":
            #return all hosts
            context = {
                "hosts": hosts  # type is list
            }
            return render_template('index.html', **context)



#after login,must return dict
@app.context_processor
def my_context_processor():
    user_id = session.get('user_id')
    if user_id:
        user = User.query.filter(User.id == user_id).first()
        if user:
            return {'user':user}
    else:
        return {}





if __name__ == '__main__':
    app.run(host="0.0.0.0",port=80,debug=True)
