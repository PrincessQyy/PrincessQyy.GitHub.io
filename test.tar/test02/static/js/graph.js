

function graph(event) {

    // console.log(event.srcElement);

    if(event.srcElement.checked === true){

        //  add item
        var temp = document.createElement("input");
        temp.name = "item";
        temp.id = event.srcElement.name;
        temp.value = event.srcElement.name;
        temp.type = "hidden";

        document.getElementById("graph").appendChild(temp);
    }
    else {
        // remove item
        var temp = document.getElementById(event.srcElement.name);
        document.getElementById("graph").removeChild(temp);

    }


}

function graph2(event) {

    if(event.srcElement.checked === true){

        //  add item
        var temp = document.createElement("input");
        temp.name = "time";
        temp.id = event.srcElement.name;
        temp.value = event.srcElement.name;
        temp.type = "hidden";

        document.getElementById("time").appendChild(temp);
    }
    else {
        // remove item
        var temp = document.getElementById(event.srcElement.name);
        document.getElementById("time").removeChild(temp);

    }

}

function host(event) {

    if(event.srcElement.checked === true){

        //  add item
        var temp = document.createElement("input");
        temp.name = "host";
        temp.id = event.srcElement.name;
        temp.value = event.srcElement.name;
        temp.type = "hidden";

        document.getElementById("host").appendChild(temp);
    }
    else {
        // remove item
        var temp = document.getElementById(event.srcElement.name);
        document.getElementById("host").removeChild(temp);

    }

}