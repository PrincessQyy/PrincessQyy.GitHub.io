# coding=utf-8
from flask_script import Manager
from flask_migrate import Migrate,MigrateCommand
from app import app
from exts import db
from models import User

manager = Manager(app )

#bonding db & app

migrate = Migrate(app,db)

#add commands to manager

manager.add_command('db',MigrateCommand)


if __name__ == "__main__":
    manager.run()
    # add_user()