# coding=utf-8
from flask import (
    Blueprint,
    request,
    jsonify,
    render_template,
    session,
    redirect,
    url_for
)

from redis import Redis
from models import User
from exts import db


#register blueprint
bp = Blueprint('user',__name__)

#regist
@bp.route('/regist/',methods=['GET','POST'])
def regist():
    if request.method == 'GET':
        return render_template('regist.html')
    else:
        telephone = request.form.get('telephone', "")
        username = request.form.get('username', "")
        password1 = request.form.get('password1', "")
        password2 = request.form.get('password2', "")

        #verify tel
        user = User.query.filter(User.telephone == telephone).first()
        if user:
            return u'该号码已被注册！请直接登录~'
        else:
            if password1 != password2 :
                return u'两次输入的密码不一样，请核对后再填写'
            else:
                user = User(telephone=telephone,username=username,password=password1)
                db.session.add(user)
                db.session.commit()
                #regist and redirect login
                return redirect(url_for('user.login'))
#login
@bp.route('/login/',methods=['GET','POST'])
def login():
    if request.method == 'GET':
        return render_template('login.html')
    else:
        telephone = request.form.get('telephone', "")
        password = request.form.get('password', "")
        user = User.query.filter(User.telephone == telephone,User.password == password).first()
        if user:
            session['user_id'] = user.id
            #如果31天内不需要登录
            session.permanet = True
            return redirect(url_for('index'))
        else:
            return u'用户名或密码错误，请确认后在登录~'
#logout
@bp.route('/logout/')
def logout():
    session.pop('user_id')
    return redirect(url_for('user.login'))
