# coding=utf-8
from flask import (
    Blueprint,
    request,
    jsonify,
    render_template,
    session,
    redirect,
    url_for
)

from redis import Redis
from models import User
from exts import db
from config import Y_dict
import re

#register blueprint
bp = Blueprint('data',__name__)



#get monitor_data
@bp.route('/data/',methods=['GET','POST'])
def get_data():
    cache = Redis(host='127.0.0.1', port=6379)
    if request.method == 'GET':
        return "get"
    else :
        data = request.get_json()
        hostname=data.get("hostname","")
        #first save
        if not cache.hexists(hostname,"hostname"):
            for key in data.keys():
                cache.hset(hostname,key,data.get(key))

        else:
            for key in data.keys():
                if key != "hostname":
                    #monitor item not exists
                    if not cache.hexists(hostname, key):
                        cache.hset(hostname, key, data.get(key))
                    else:
                        temp = str(cache.hget(hostname,key))+ ','+ str(data.get(key))
                        cache.hset(hostname,key,str(temp))
        return "get data!!!"

#

#create graphs
@bp.route('/graph/',methods=['GET',"POST"])
def graph():

    #connect to redis
    cache = Redis(host='127.0.0.1', port=6379)

    #get hosts and time
    new_hosts=request.form.get("now")
    time=request.form.get("time")
    if time == "hour":
        temp_item = []
        items = []
        host_temp = []
        hosts = []
        timestamp = []
        Y_list = []
        new_hosts=new_hosts.encode("utf-8")
        new_hosts=new_hosts.replace("\'","")
        new_hosts=new_hosts.replace("[","")
        new_hosts=new_hosts.replace("]","")
        new_hosts=new_hosts.split(",")

        for each in new_hosts:
            each=each.strip()
            # get special hosts
            hosts.append(str(each))
            # get item_data
            hostname = str(each.split(".")[0])
            item = str(each.split(".")[1])
            y = Y_dict[item]
            Y_list.append(y)
            temp = cache.hget(hostname, item)

            for each in temp.split(","):
                temp_item.append(float(each))

            # get 10 point
            item_temp = []
            temp_item.reverse()
            for i in range(0, 180, 6):
                item_temp.append(temp_item[i])
            item_temp.reverse()
            items.append(item_temp)
            temp_item = []

        # get time
        hostname = str(new_hosts[0]).split(".")
        hostname = str(hostname[0])

        time_temp = cache.hget(hostname, "time")
        time_temp = time_temp.split(",")
        # get 10 point
        time_temp.reverse()

        for i in range(0, 180,6):
            timestamp.append(time_temp[i])

        timestamp.reverse()

        context = {
            "hosts": hosts,
            "items": items,
            "timestamp": timestamp,
            "Y_list": Y_list,
        }

        return render_template("graph.html",**context)

    elif time == "day":
        new_hosts = new_hosts.encode("utf-8")
        new_hosts = new_hosts.replace("\'", "")
        new_hosts = new_hosts.replace("[", "")
        new_hosts = new_hosts.replace("]", "")
        new_hosts = new_hosts.split(",")
        return render_template("graph.html")
    elif time == "week":
        print"week"
        print new_hosts
        return render_template("graph.html")


    graph_data = request.form.getlist("item")
    temp_item=[]
    items=[]
    host_temp=[]
    hosts=[]
    timestamp_temp=[]
    timestamp=[]
    Y_list=[]
    for each in graph_data:
        #get special hosts
        hosts.append(str(each))
        #get item_data
        hostname = str(each.split(".")[0])
        item = str(each.split(".")[1])
        y=Y_dict[item]
        Y_list.append(y)
        temp = cache.hget(hostname,item)
        for each in temp.split(","):
            temp_item.append(float(each))
        #get 10 point
        item_temp=[]
        temp_item.reverse()
        for i in range(0, 60,2):
            item_temp.append(temp_item[i])
        item_temp.reverse()
        items.append(item_temp)
        temp_item=[]


    #get time
    hostname=str(graph_data[0]).split(".")
    hostname=str(hostname[0])

    time_temp=cache.hget(hostname,"time")
    time_temp = time_temp.split(",")
    #get 10 point
    time_temp.reverse()
    for i in range(0,60,2):
        timestamp_temp.append(time_temp[i])

    timestamp_temp.reverse()
    for each in timestamp_temp:
        each = each.split("-")[3]
        timestamp.append(each)


    context={
        "hosts":hosts,
        "items":items,
        "timestamp":timestamp,
        "Y_list":Y_list,
    }
    return render_template("graph.html",**context)











