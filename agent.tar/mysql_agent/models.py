# coding=utf-8
from sqlalchemy import (
    Column,
    String,
    create_engine,
    MetaData,
    Table
    )
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base
from redis import Redis
from config import *
import pymysql


cache = Redis(host='127.0.0.1', port=6379)



def get_hosts():

    hosts = cache.keys()
    return hosts


def get_data(hosts,conn,DBsession):

    data = cache.hgetall(hosts[0])
    data.pop("hostname")
    time_temp = data["time"]
    time = time_temp.split(",")
    for each in time:
        coloum_name_list = []
        coloum_value_list = []
        data_dict={}
        tablename = each
        for item in data.keys():
            coloum_name_list.append(item)
            value = data[item]
            value_list = value.split(",")
            coloum_value_list .append(value_list[time.index(each)])
            data_dict[item]=value_list[time.index(each)]
        #print tablename,coloum_name_list,coloum_value_list
        create_table(tablename,data_dict,conn,DBsession)

def create_table(tablename,data_dict,conn,DBsession):

    tablename = tablename
    table = Table(tablename,metadata,
                  Column("tcp_InSegs",String(100)),
                  Column("TCPAbortFailed",String(100)),
                  Column("TCPLossFailures",String(100)),
                  Column("tcp_OutSegs",String(100)),
                  Column("TCPAbortOnMemory",String(100)),
                  Column("TCPLoss",String(100)),
                  Column("cpu_iowait",String(100)),
                  Column("udp_OutDatagrams",String(100)),
                  Column("menfree_percent",String(100)),
                  Column("udp_InDatagrams",String(100)),
                  Column("cpu_idle",String(100)),
                  Column("TCPTSReorder",String(100)),
                  Column("tcp_CurrEstab",String(100)),
                  Column("TCPSpuriousRTOs",String(100)),
                  Column("cpu_irq",String(100)),
                  Column("cpu_softirq",String(100)),
                  Column("files_percent",String(100)),
                  Column("TcpListenOverflows",String(100)),
                  Column("tcp_InErrs",String(100)),
                  Column("load",String(100)),
                  Column("udp_InErrs",String(100)),
                  Column("TcpListenDrops",String(100)),
                  Column("swapfree_percent",String(100)),
                  Column("/dev/boot_use",String(100)),
                  Column("TW",String(100)),
                  )

    # 创建数据表，如果数据表存在则忽视！！！
    metadata.create_all(engine)
    db = table.insert()
    conn.execute(db,**data_dict)

if __name__ == "__main__":

    hosts=get_hosts()
    #print hosts
    for host in hosts:
        DATABASE = host
        DB_URI = DB_URI = "mysql+pymysql://{}:{}@{}:{}/{}?charset=utf8".format(USERNAME, PASSWORD, HOSTNAME, PORT, DATABASE)
        SQLALCHEMY_DATABASE_URI = DB_URI

        # 定义数据库引擎
        engine = create_engine(SQLALCHEMY_DATABASE_URI)


        #engine = create_engine('mysql+pymysql://root:Princess143.@127.0.0.1:3306/test01?charset=utf8')
        # 绑定元信息
        metadata = MetaData(engine)
        # 获取数据库链接，以备后面使用！！！！！
        conn = engine.connect()
        DBSession = sessionmaker(bind=engine)

        get_data(hosts,conn,DBSession)


