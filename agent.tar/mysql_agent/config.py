# coding=utf-8

#mysql
HOSTNAME = "127.0.0.1"
PORT = "3306"
USERNAME = "root"
PASSWORD = "Princess143."


SQLALCHEMY_TRACK_MODIFICATIONS = False